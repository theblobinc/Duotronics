# Corpus Index - Duotronic v1.6 Draft 4.1

Status: final generated corpus index.
Generated: 2026-05-09.

## Summary

- Total files indexed: 258
- Markdown files indexed: 245
- Non-Markdown files indexed: 13
- Base: complete uploaded Draft 4 carry-forward plus Draft 4.1 closeout layer.

## Primary Draft 4.1 files

- `START_HERE.md`
- `README.md`
- `START_HERE_v1_6_draft_4_1.md`
- `README_v1_6_draft_4_1.md`
- `RELEASE_NOTES_v1_6_draft_4_1.md`
- `CORPUS_INDEX_v1_6_draft_4_1.md`
- `duotronic_draft4_1_contract_closeout_report.md`
- `duotronic_draft4_1_witness_contract_version_alias_and_migration_profile_v1_0.md`
- `mcp/mcp_recurrence_tool_availability_matrix_v1_6_draft_4_1.md`
- `runtime/wgrnn_chat_context_injection_witness_contract_v1_0.md`
- `browser/browser_chat_workbench_invocation_witness_contract_v1_0.md`
- `duotronic_draft4_1_agent_lab_mutation_safety_config_witness_profile_v1_0.md`
- `runtime/runtime_feature_applicability_witness_contract_v1_0.md`
- `runtime/runtime_readiness_evidence_persistence_profile_v1_0.md`
- `tests/draft4_1_conformance_delta_validation_plan_v1_0.md`
- `refs/manifest/MANIFEST_v1_6_draft_4_1_complete.md`

## Files by top-level area

### .

- `CORPUS_INDEX_v1_6_draft_3.md`
- `CORPUS_INDEX_v1_6_draft_4.md`
- `CORPUS_INDEX_v1_6_draft_4_1.md`
- `DRAFT4_1_VALIDATION_SUMMARY.txt`
- `DRAFT4_VALIDATION_SUMMARY.txt`
- `IMPLEMENTATION_READINESS_GAP_CLOSURE_v1_6_draft_1_retained.md`
- `IMPLEMENTATION_READINESS_GAP_CLOSURE_v1_6_draft_2.md`
- `LICENSE.md`
- `PACKAGE_INVENTORY_v1_6_draft_4_1.json`
- `PACKAGE_METADATA_v1_6_draft_4_1.json`
- `RC_BLOCKER_CLOSURE_MATRIX_v1_6_draft_3.md`
- `README.md`
- `README_v1_6_draft_1_retained_for_history.md`
- `README_v1_6_draft_2.md`
- `README_v1_6_draft_3.md`
- `README_v1_6_draft_3_completed.md`
- `README_v1_6_draft_3_updated.md`
- `README_v1_6_draft_4.md`
- `README_v1_6_draft_4_1.md`
- `RELEASE_NOTES_v1_6_draft_1_retained_for_history.md`
- `RELEASE_NOTES_v1_6_draft_2.md`
- `RELEASE_NOTES_v1_6_draft_3.md`
- `RELEASE_NOTES_v1_6_draft_3_completed.md`
- `RELEASE_NOTES_v1_6_draft_3_updated.md`
- `RELEASE_NOTES_v1_6_draft_4.md`
- `RELEASE_NOTES_v1_6_draft_4_1.md`
- `START_HERE.md`
- `START_HERE_v1_6_draft_3_rc_closure.md`
- `START_HERE_v1_6_draft_4.md`
- `START_HERE_v1_6_draft_4_1.md`
- `corpus_review_v1_3_draft_4_to_v1_4_draft.md`
- `corpus_review_v1_4_draft_2_to_v1_4_draft_3.md`
- `corpus_review_v1_4_draft_3_to_v1_4_draft_4.md`
- `corpus_review_v1_4_draft_4_to_v1_4_draft_5.md`
- `corpus_review_v1_4_draft_5_to_v1_6_draft.md`
- `corpus_review_v1_4_draft_to_v1_4_draft_2.md`
- `corpus_review_v1_6_draft_1_to_v1_6_draft_2.md`
- `corpus_review_v1_6_draft_2_to_v1_6_draft_3.md`
- `corpus_review_v1_6_draft_3_to_v1_6_draft_4.md`
- `corpus_review_v1_6_draft_4_to_v1_6_draft_4_1.md`
- `corpus_review_v1_6_draft_to_v1_6_draft_2.md`
- `duotronic_admin_interface_spec_v1_0.md`
- `duotronic_all_math_witness_contract_v1_0.md`
- `duotronic_api_contract_v1_0.md`
- `duotronic_application_notes_completed.md`
- `duotronic_code_interpreter_plan_v1_0.md`
- `duotronic_cognition_loop_migration_note_v1_0.md`
- `duotronic_conformance_test_suite_v1_0.md`
- `duotronic_corpus_migration_witness_spec_v1_0.md`
- `duotronic_database_schema_v1_0.md`
- `duotronic_dbp_v2_envelope_spec.md`
- `duotronic_deployment_guide_v1_0.md`
- `duotronic_dmql_backend_plan_v1_0.md`
- `duotronic_dpfc_canon_bridge_v1_0.md`
- `duotronic_draft3_completed_source_refresh_2026_04_30.md`
- `duotronic_draft4_1_agent_lab_mutation_safety_config_witness_profile_v1_0.md`
- `duotronic_draft4_1_contract_closeout_report.md`
- `duotronic_draft4_1_validation_and_completeness_report.md`
- `duotronic_draft4_1_witness_contract_version_alias_and_migration_profile_v1_0.md`
- `duotronic_draft4_agent_lab_mutation_backup_witness_profile_v1_0.md`
- `duotronic_draft4_runtime_model_observability_profile_v1_0.md`
- `duotronic_draft4_srnaction_to_witness_mapping_v1_0.md`
- `duotronic_draft4_srnn_source_refresh_2026_05_08.md`
- `duotronic_draft4_validation_and_completeness_report.md`
- `duotronic_draft_3_source_refresh_summary_2026_04_30.md`
- `duotronic_formal_models_and_proof_status_profile_v1_0.md`
- `duotronic_formal_semantics_and_verification_v1_0.md`
- `duotronic_human_review_state_machine_v1_0.md`
- `duotronic_interoperability_standards_profile_v1_0.md`
- `duotronic_langlands_canon_contract_v1_0.md`
- `duotronic_math_query_language_v1_0.md`
- `duotronic_mathematical_canon_contract_v1_0.md`
- `duotronic_mathledger_optional_trust_model_v0_1.md`
- `duotronic_mcp_missing_runtime_tools_backlog_v1_0.md`
- `duotronic_mcp_policy_snapshot_2026_04_30.md`
- `duotronic_mcp_recurrence_tool_api_contract_v1_0.md`
- `duotronic_mcp_runtime_observation_log_2026_04_30.md`
- `duotronic_mcp_runtime_observation_log_2026_04_30_draft_3.md`
- `duotronic_mcp_server_tooling_integration_v1_0.md`
- `duotronic_mcp_tool_manifest_snapshot_2026_04_30.md`
- `duotronic_migration_runbook_v1_6.md`
- `duotronic_minecraft_mcp_action_profile_v1_1.md`
- `duotronic_multimodal_witness_runtime_profile_v1_1.md`
- `duotronic_mutation_policy_defaults_profile_v1_0.md`
- `duotronic_mutation_policy_validation_profile_v1_1.md`
- `duotronic_observability_opentelemetry_profile_v1_0.md`
- `duotronic_openapi_and_sdk_plan_v1_0.md`
- `duotronic_openapi_cognition_migration_profile_v1_1.md`
- `duotronic_openapi_runtime_surface_inventory_v1_0.md`
- `duotronic_operations_manual_v1_0.md`
- `duotronic_phase3_validation_suite_profile_v1_0.md`
- `duotronic_policy_engine_spec_v1_0.md`
- `duotronic_polyglot_bridge_protocol_v1_0.md`
- `duotronic_polyglot_runtime_contract_v1_0.md`
- `duotronic_polygon_family_calculus_v6_0.md`
- `duotronic_production_release_checklist_v1_0.md`
- `duotronic_program_charter_v1_6.md`
- `duotronic_proof_and_conjecture_witness_contract_v1_0.md`
- `duotronic_proof_interchange_and_certificates_v1_0.md`
- `duotronic_reference_implementation_plan_v1_0.md`
- `duotronic_replay_package_spec_v1_0.md`
- `duotronic_runtime_recurrence_complete_integration_document_v1_0.md`
- `duotronic_runtime_recurrence_tuning_profile_v1_2.md`
- `duotronic_sandbox_specification_v1_0.md`
- `duotronic_sdk_and_openapi_integration_profile_v1_1.md`
- `duotronic_sdk_formal_models_security_profile_v1_1.md`
- `duotronic_sdk_threat_model_security_closure_plan_v1_0.md`
- `duotronic_security_architecture_v1_0.md`
- `duotronic_specification_governance_v1_0.md`
- `duotronic_srnn_backend_current_state_review_2026_04_30.md`
- `duotronic_srnn_federated_runtime_stack_profile_v1_0.md`
- `duotronic_srnn_git_commit_integration_notes_2026_04_30.md`
- `duotronic_srnn_gpu_worker_llama_server_runtime_profile_v1_0.md`
- `duotronic_srnn_integration_addendum_v1_0.md`
- `duotronic_srnn_mcp_endpoint_observation_log_2026_04_30.md`
- `duotronic_srnn_mcp_endpoint_query_contract_v1_0.md`
- `duotronic_srnn_source_update_review_2026_04_30_draft_3.md`
- `duotronic_srnn_source_update_review_2026_04_30_draft_3_update.md`
- `duotronic_srnn_task_queue_schema_v1_0.md`
- `duotronic_stdio_principal_policy_v1_0.md`
- `duotronic_stridethreat_model_v1_0.md`
- `duotronic_temporal_witness_and_absence_profile_v1_0.md`
- `duotronic_update_application_notes_v1_6_draft_3.md`
- `duotronic_use_case_examples_v1_0.md`
- `duotronic_v1_6_backend_upgrade_patch.md`
- `duotronic_v1_6_distributed_self_governing_recurrent_network_addendum.md`
- `duotronic_v1_6_draft_3_next_steps.md`
- `duotronic_wgrnn_firehose_integration_profile_v1_0.md`
- `duotronic_wgrnn_gate_reference_defaults_v1_0.md`
- `duotronic_wgrnn_temporal_authority_runtime_contract_v1_1.md`
- `duotronic_witness_contract_v11_0.md`
- `implementation_readiness_gap_closure_v1_2.md`
- `implementation_readiness_gap_closure_v1_6_draft_4.md`
- `implementation_readiness_gap_closure_v1_6_draft_4_1.md`
- `v1_6_draft_2_next_steps.md`
- `v1_6_draft_2_reading_guide.md`

### architecture

- `architecture/polyglot_runtime_justification_v1_0.md`

### benchmarks

- `benchmarks/witness_runtime_benchmark_plan_v1_0.md`

### browser

- `browser/browser_chat_workbench_invocation_witness_contract_v1_0.md`

### executable

- `executable/openapi/duotronic_openapi_v1_6_draft_3_rc1.yaml`
- `executable/openapi/duotronic_openapi_v1_6_draft_3_rc1.yaml.md`
- `executable/sql/001_cognition_step_and_witness_runtime.sql`
- `executable/sql/001_cognition_step_and_witness_runtime.sql.md`
- `executable/sql/002_mcp_recurrence_tools_schema.sql`
- `executable/sql/002_mcp_recurrence_tools_schema.sql.md`

### formal

- `formal/lean4/DuotronicCore.lean`
- `formal/lean4/DuotronicCore.lean.md`
- `formal/tlaplus/TaskDelegationAndPolicyCoreSpec.tla`
- `formal/tlaplus/TaskDelegationAndPolicyCoreSpec.tla.md`

### mcp

- `mcp/mcp_recurrence_conformance_matrix_v1_2.md`
- `mcp/mcp_recurrence_tool_api_contract_v1_2.md`
- `mcp/mcp_recurrence_tool_availability_matrix_v1_6_draft_4_1.md`
- `mcp/mcp_runtime_authority_delta_v1_6_draft_4.md`

### migration

- `migration/draft4_to_draft4_1_migration_runbook.md`
- `migration/v1_5_to_v1_6_migration_and_rollback_runbook_v1_0.md`
- `migration/v1_6_draft_3_to_draft_4_migration_note.md`

### refs

- `refs/backend_runtime_registry_v1_0.md`
- `refs/conformance_fixtures_v1_0.md`
- `refs/deprecated/DEPRECATED_DRAFT3_DOCUMENTS.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_cognition_step_migration_and_snapshot_profile_v1_1.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_direct_mutation_tools_security_addendum_v1_0.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_direct_mutation_tools_security_addendum_v1_1.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_live_recurrent_witness_overlay_contract_v1_0.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_live_recurrent_witness_overlay_contract_v1_1.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_mcp_verified_vs_target_tool_matrix_v1_0.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_mcp_verified_vs_target_tool_matrix_v1_1.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_runtime_recurrence_tuning_profile_v1_0.md`
- `refs/deprecated/draft3_superseded_same_day_docs/duotronic_runtime_recurrence_tuning_profile_v1_1.md`
- `refs/diagrams/duotronic_v1_4_corpus_architecture_16x9.png.md`
- `refs/duotronic_auto_profile_learning_contract_v1_3.md`
- `refs/duotronic_chronological_self_evidence_contract_v1_2.md`
- `refs/duotronic_container_deployment_and_node_lifecycle_reference_v1_0.md`
- `refs/duotronic_dbp_inter_node_full_duplex_profile_v1_0.md`
- `refs/duotronic_distributed_model_node_protocol_v1_2.md`
- `refs/duotronic_distributed_task_delegation_and_resource_witness_contract_v1_0.md`
- `refs/duotronic_evidence_purge_and_privacy_deletion_contract_v1_0.md`
- `refs/duotronic_family_registry_v1_4.md`
- `refs/duotronic_glossary_v1_0.md`
- `refs/duotronic_human_review_and_escalation_protocol_v1_0.md`
- `refs/duotronic_internal_decision_and_planning_contract_v1_2.md`
- `refs/duotronic_lab_evidence_registry_v1_7.md`
- `refs/duotronic_lab_integrated_source_corpus_index_v1_13.md`
- `refs/duotronic_lookup_memory_and_replay_profile_v1_2.md`
- `refs/duotronic_meta_runtime_contract_v0_5.md`
- `refs/duotronic_migration_guide_v1_3.md`
- `refs/duotronic_model_diversity_and_adjudication_governance_v1_1.md`
- `refs/duotronic_node_federation_protocol_v1_0.md`
- `refs/duotronic_normalizer_profiles_v1_3.md`
- `refs/duotronic_policy_shield_guide_v1_8.md`
- `refs/duotronic_profile_synthesis_registry_v1_2.md`
- `refs/duotronic_representation_bridge_contract_v1_1.md`
- `refs/duotronic_retention_diagnostics_v1_4.md`
- `refs/duotronic_schema_registry_v1_10.md`
- `refs/duotronic_search_social_evidence_ingestion_v1_3.md`
- `refs/duotronic_source_architecture_overview_v1_7.md`
- `refs/duotronic_transport_profiles_v1_3.md`
- `refs/duotronic_v1_6_cluster_conformance_fixtures_v1_0.md`
- `refs/duotronic_witness_gated_recurrent_cell_contract_v1_0.md`
- `refs/examples/duotronic_wgrnn_pytorch_skeleton_v1_0.md`
- `refs/examples/duotronic_worked_self_informing_loop_youtube_music_v1_0.md`
- `refs/examples/wgrnn_replay_identity_fixture_v1.json`
- `refs/fixtures/duotronic_fixtures_v1_6_markdown_pack.md`
- `refs/langlands_object_registry_v1_0.md`
- `refs/language_runtime_registry_v1_0.md`
- `refs/manifest/CHECKSUMS_v1_6_draft_4.sha256`
- `refs/manifest/CHECKSUMS_v1_6_draft_4_1.sha256`
- `refs/manifest/CORPUS_INDEX_v1_6_draft_2.md`
- `refs/manifest/CORPUS_INDEX_v1_6_draft_3.md`
- `refs/manifest/MANIFEST.md`
- `refs/manifest/MANIFEST_v1_6_draft_1_implementation_ready_retained.md`
- `refs/manifest/MANIFEST_v1_6_draft_2_complete.md`
- `refs/manifest/MANIFEST_v1_6_draft_3_complete.md`
- `refs/manifest/MANIFEST_v1_6_draft_3_completed.md`
- `refs/manifest/MANIFEST_v1_6_draft_3_rc_closure.md`
- `refs/manifest/MANIFEST_v1_6_draft_3_updated.md`
- `refs/manifest/MANIFEST_v1_6_draft_4_1_complete.md`
- `refs/manifest/MANIFEST_v1_6_draft_4_1_release.json`
- `refs/manifest/MANIFEST_v1_6_draft_4_1_release.json.md`
- `refs/manifest/MANIFEST_v1_6_draft_4_complete.md`
- `refs/manifest/MANIFEST_v1_6_draft_4_release.json.md`
- `refs/manifest/MANIFEST_v1_6_full_upgrade.md`
- `refs/mathematical_claim_status_ladder_v1_0.md`
- `refs/mathematical_domain_registry_v1_0.md`
- `refs/release_manifest_v1_5_draft_2_v1_6_markdown_schema.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_acoustics_spectral_witnesses_v1_2.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_edo_temperament_v1_2.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_gcd_jump_recurrences_v1_0.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_pronic_centered_polygon_families_v1_0.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_qcd_spin_correlation_analogy_v1_2.md`
- `refs/research_profiles/carried_forward/duotronic_research_profile_selective_witness_state_spaces_v1_0.md`
- `refs/research_profiles/duotronic_reference_profile_english_claim_evidence_v0_2.md`
- `refs/research_profiles/duotronic_reference_profile_glyphic_script_visual_semantic_v0_2.md`
- `refs/research_profiles/duotronic_reference_profile_roman_numerals_v0_1.md`
- `refs/review_notes/user_gap_analysis_implementation_readiness_v1_6_draft_1.md`
- `refs/review_notes/user_gap_analysis_production_hardening_v1_6_draft_1.md`
- `refs/runtime_observations/mcp_raw_observation_summaries_2026_04_30.md`
- `refs/schemas/duotronic_v1_5_draft_2_starter_object_shapes_v1_6_markdown_schema.md`
- `refs/source_observations/docker_compose_federated_stack_observation_2026_05_08.md`
- `refs/source_observations/gpu_worker_app_observation_2026_05_08.md`
- `refs/source_observations/llama_server_runtime_observation_2026_05_08.md`
- `refs/source_observations/srnn_recent_commit_observation_2026_05_08.md`
- `refs/source_observations/srnn_server_draft4_1_source_observation_notes_2026_05_09.md`
- `refs/source_review_srnn_server_2026_04_30.md`
- `refs/v1_5_to_v1_6_coverage_map.md`

### runtime

- `runtime/cognition_loop_boundary_spec_v1_0.md`
- `runtime/cognition_snapshot_migration_v1_2.md`
- `runtime/live_recurrent_witness_overlay_contract_v1_2.md`
- `runtime/llama_server_runtime_readiness_contract_v1_0.md`
- `runtime/runtime_feature_applicability_witness_contract_v1_0.md`
- `runtime/runtime_readiness_evidence_persistence_profile_v1_0.md`
- `runtime/srnn_backend_drift_closure_v1_0.md`
- `runtime/wgrnn_chat_context_injection_witness_contract_v1_0.md`

### security

- `security/direct_mutation_tool_enforcement_v1_2.md`
- `security/gpu_worker_runtime_security_and_memlock_profile_v1_0.md`
- `security/stride_threat_model_v1_2.md`

### tests

- `tests/draft4_1_conformance_delta_validation_plan_v1_0.md`
- `tests/draft4_conformance_validation_plan_v1_0.md`
- `tests/end_to_end_integration_test_suite_v1_0.md`
