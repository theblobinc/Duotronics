# Executable OpenAPI — Duotronic v1.6 Draft 3 RC1

Status: executable artifact in Markdown wrapper.

To use: extract the YAML block into `duotronic_openapi_v1_6_draft_3_rc1.yaml` and validate with an OpenAPI 3.1 validator.

```yaml
openapi: 3.1.0
info:
  title: Duotronic API
  version: 1.6-draft-3-rc1
  description: Executable OpenAPI surface for Duotronic witness, recurrence, policy, replay, math, and MCP recurrence tools.
servers:
  - url: https://www.xavi.app/duotronic/v1
paths:
  /health:
    get:
      operationId: getHealth
      responses:
        "200":
          description: Health response
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ApiResponse"
  /version:
    get:
      operationId: getVersion
      responses:
        "200":
          description: Version response
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ApiResponse"
  /math/objects:
    get:
      operationId: listMathObjects
      parameters:
        - name: domain
          in: query
          required: false
          schema: { type: string }
        - name: object_type
          in: query
          required: false
          schema: { type: string }
        - name: limit
          in: query
          required: false
          schema: { type: integer, minimum: 1, maximum: 200, default: 20 }
      responses:
        "200":
          description: Math objects
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /policy/decide:
    post:
      operationId: decidePolicy
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: "#/components/schemas/PolicyDecisionRequest" }
      responses:
        "200":
          description: Policy decision
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /mcp/recurrence/write_witness:
    post:
      operationId: writeWitness
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: "#/components/schemas/WriteWitnessRequest" }
      responses:
        "200":
          description: Witness write result
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /mcp/recurrence/propose_decay:
    post:
      operationId: proposeDecay
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: "#/components/schemas/DecayIntentWitness" }
      responses:
        "200":
          description: Decay proposal result
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /mcp/recurrence/query_overlay:
    get:
      operationId: queryOverlay
      parameters:
        - name: loop_id
          in: query
          required: false
          schema: { type: string }
      responses:
        "200":
          description: Live recurrent witness overlay
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /mcp/recurrence/query_slot:
    get:
      operationId: querySlot
      parameters:
        - name: slot_id
          in: query
          required: true
          schema: { type: string }
      responses:
        "200":
          description: Slot state
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
  /mcp/recurrence/emit_meta_diagnostics:
    post:
      operationId: emitMetaDiagnostics
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: "#/components/schemas/MetaDiagnostics" }
      responses:
        "200":
          description: Diagnostic witness
          content:
            application/json:
              schema: { $ref: "#/components/schemas/ApiResponse" }
components:
  schemas:
    ApiResponse:
      type: object
      required: [ok, request_id, result, error]
      properties:
        ok: { type: boolean }
        request_id: { type: string }
        envelope_id: { type: string }
        policy_decision_id: { type: string }
        replay_identity_ref: { type: string }
        result: {}
        error: { type: string }
        signature:
          anyOf:
            - { $ref: "#/components/schemas/ResponseSignature" }
            - { type: "null" }
    ResponseSignature:
      type: object
      required: [signer_id, signature_alg, body_sha3_256, signature]
      properties:
        signer_id: { type: string }
        signature_alg: { type: string, enum: [HMAC-SHA256, Ed25519] }
        body_sha3_256: { type: string }
        signature: { type: string }
    TemporalWitness:
      type: object
      required: [temporal_witness_id, origin, clock_family, tick_family, count, authority_t, freshness_state, replay_identity_ref]
      properties:
        temporal_witness_id: { type: string }
        origin: { type: string }
        clock_family:
          type: string
          enum: [real_time, monotonic_process, game_tick, media_frame, proof_step, simulated_tick, external]
        tick_family: { type: string }
        count: { type: integer }
        canonical_ts: { type: number }
        observed_at: { type: number }
        ingested_at: { type: number }
        source_clock: { type: string }
        binding_confidence: { type: number, minimum: 0, maximum: 1 }
        authority_t: { type: number, minimum: 0, maximum: 1 }
        freshness_state: { type: string, enum: [current, stale, future, unknown] }
        ttl_class: { type: string, enum: [ephemeral, slow_changing, stable, permanent, policy_bound] }
        replay_identity_ref: { type: string }
    WriteWitnessRequest:
      type: object
      required: [witness_kind, payload, temporal_witness]
      properties:
        witness_kind: { type: string }
        payload: { type: object }
        temporal_witness: { $ref: "#/components/schemas/TemporalWitness" }
        replay_identity_ref: { type: string }
    DecayIntentWitness:
      type: object
      required: [decay_witness_id, slot_id, curve_family, proposed_rate, proposed_by, reason]
      properties:
        decay_witness_id: { type: string }
        slot_id: { type: string }
        curve_family: { type: string, enum: [exponential, linear, step, custom] }
        half_life_s: { type: number }
        proposed_rate: { type: number }
        proposed_by: { type: string, enum: [L2, L3, L4, L5, human, policy] }
        reason: { type: string }
        policy_decision_id: { type: string }
        effective_from: { $ref: "#/components/schemas/TemporalWitness" }
    PolicyDecisionRequest:
      type: object
      required: [action, principal]
      properties:
        action: { type: string }
        principal: { type: object }
        auth_strength: { type: string }
        runtime_mode: { type: string }
        evidence_refs:
          type: array
          items: { type: string }
    MetaDiagnostics:
      type: object
      required: [loop_id, temporal_witness, gate_counts]
      properties:
        loop_id: { type: string }
        temporal_witness: { $ref: "#/components/schemas/TemporalWitness" }
        gate_counts: { type: object }
        slot_lifecycle_stats: { type: object }
        replay_divergence: { type: number }
        quarantine_age_ms: { type: number }
```

